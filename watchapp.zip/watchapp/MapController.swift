//
//  MapController.swift
//  POC
//
//  Created by Kavya V. Hegde on 4/22/15.
//  Copyright (c) 2015 Kavya V. Hegde. All rights reserved.
//

import WatchKit
import Foundation
import MapKit
import CoreLocation

class MapController: WKInterfaceController,CLLocationManagerDelegate,MKMapViewDelegate{

    @IBOutlet weak var Map: WKInterfaceMap!
    let locationManager = CLLocationManager()
    //override vi
  //  @IBAction func YourLocatio() {
//        let coordinateSpan = MKCoordinateSpan(latitudeDelta: 0.005, longitudeDelta: 0.005)
//        let location = CLLocationCoordinate2D(
//            latitude: 12.9667,
//            //40.74836,
//            longitude:77.5667
//            //-73.984607
//        )
//
//        
//        Map.addAnnotation(location, withPinColor: .Red)
//        Map.setVisibleMapRect(MKMapRect(origin: MKMapPointForCoordinate(location),
//            size: MKMapSize(width: 0.5, height: 0.5)))
//        Map.setRegion(MKCoordinateRegion(center: location, span: coordinateSpan))
        
       // }
        
    
    
    
    override func awakeWithContext(context: AnyObject?) {
        super.awakeWithContext(context)
               // Configure interface objects here.
        let location = CLLocationCoordinate2D(latitude: 12.9667, longitude: 77.5667)
        let coordinateSpan = MKCoordinateSpan(latitudeDelta: 10, longitudeDelta: 10)
        Map.addAnnotation(location, withPinColor: .Purple)
        Map.setRegion(MKCoordinateRegion(center: location, span: coordinateSpan))    }
    
        
        
       
        
        
override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

}
