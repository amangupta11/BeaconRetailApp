//
//  ListController.swift
//  POC
//
//  Created by Kavya V. Hegde on 4/22/15.
//  Copyright (c) 2015 Kavya V. Hegde. All rights reserved.
//work

import WatchKit
import Foundation

class ListController: WKInterfaceController
{
    
   //var _eventsData:[Event] = [Event]()
    var offerItem: Event!
    
    
    @IBOutlet weak var Detail: WKInterfaceButton!
    @IBOutlet weak var featurePrice: WKInterfaceLabel!
    @IBOutlet weak var featureLabel: WKInterfaceLabel!
   // @IBOutlet weak var featureImage: WKInterfaceImage!
    
    // @IBOutlet weak var table: WKInterfaceTable!
   
    
    @IBAction func Button() {
  //  SecondController offerItem.eventTitle
     //presentControllerWithName("SecondController", context:self.offerItem)
    //pushControllerWithName ("SecondController", context:self.offerItem)
        
   }

    override func awakeWithContext(context: AnyObject!)
    {
        if let Event = context as? Event{
        offerItem = Event
            
            
        featureLabel.setText(Event.eventTitle)
        featurePrice.setText(Event.eventPrice)
        Detail.setBackgroundImageNamed(Event.eventImageName)
        //featureLabel.setTextColor((red: 160/255.0), green: (75/255.0), blue: (15/255.0), alpha: 1.0)
                  }
      
    }
    


    override func willActivate() {
        super.willActivate()
        
    }
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }
}
