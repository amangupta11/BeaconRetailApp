//
//  InterfaceController.swift
//  POC WatchKit Extension
//
//  Created by Kavya V. Hegde on 4/22/15.
//  Copyright (c) 2015 Kavya V. Hegde. All rights reserved.
//

import WatchKit
import Foundation


class InterfaceController: WKInterfaceController {
    
    
    @IBOutlet weak var List: WKInterfaceButton!
   
    @IBOutlet weak var cart: WKInterfaceButton!
    @IBOutlet weak var offers: WKInterfaceButton!
        @IBOutlet weak var Wallet: WKInterfaceButton!
    
//et features=["","]
   // let features = ["Apps","Image"]
      var _eventsData:[Event] = [Event]()
    
    
  //  var img:UIImage(named:"cart.png")!
    @IBAction func BrowsebuttonTapped()
    {
        
        let controllers = [String](count: _eventsData.count, repeatedValue: "ListController")
        presentControllerWithNames(controllers, contexts: _eventsData)
        
    }
    override func awakeWithContext(context: AnyObject?) {
        _eventsData = Event.eventsList()
        
               super.awakeWithContext(context)
        
        
        var img:UIImage = UIImage(named: "Shopping_List.png")!
        WKInterfaceDevice().addCachedImage(img, name: "Shopping_List.png")
        
        self.List.setBackgroundImageNamed("Shopping_List.png")
        
        var img1:UIImage = UIImage(named: "wallet.png")!
        WKInterfaceDevice().addCachedImage(img1, name: "wallet.png")
        
        self.Wallet.setBackgroundImageNamed("wallet.png")
        
        var img2:UIImage = UIImage(named: "my_offers.png")!
        WKInterfaceDevice().addCachedImage(img2, name: "my_offers.png")
        
        self.offers.setBackgroundImageNamed("my_offers.png")
        
        var img3:UIImage = UIImage(named: "cart.png")!
        WKInterfaceDevice().addCachedImage(img3, name: "cart.png")
        
        self.cart.setBackgroundImageNamed("cart.png")
    }
    
    override func willActivate() {
        super.willActivate()
        
    }
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

 

    
   override func contextsForSegueWithIdentifier(segueIdentifier: String) -> [AnyObject]? {
     
       return _eventsData
        
    }
    }

