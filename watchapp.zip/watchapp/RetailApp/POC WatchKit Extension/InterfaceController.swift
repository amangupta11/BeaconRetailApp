//
//  InterfaceController.swift
//  POC WatchKit Extension
//
//  Created by Kavya V. Hegde on 4/22/15.
//  Copyright (c) 2015 Kavya V. Hegde. All rights reserved.
//

import WatchKit
import Foundation


class InterfaceController: WKInterfaceController {
    
    
    
//et features=["","]
   // let features = ["Apps","Image"]
      var _eventsData:[Event] = [Event]()
    
    
    
    @IBAction func BrowsebuttonTapped()
    {
        
        let controllers = [String](count: _eventsData.count, repeatedValue: "ListController")
        presentControllerWithNames(controllers, contexts: _eventsData)
        
    }
    override func awakeWithContext(context: AnyObject?) {
        _eventsData = Event.eventsList()
        
        //for event in _eventsData {
            
           // var typeFound = false
            
           //  let eventImage = event.eventImageName
       // }
        super.awakeWithContext(context)
    }
    
    override func willActivate() {
        super.willActivate()
        
    }
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

 

    
   override func contextsForSegueWithIdentifier(segueIdentifier: String) -> [AnyObject]? {
     
       return _eventsData
        
    }
    }

