//
//  Event.swift
//  POC
//
//  Created by Kavya V. Hegde on 5/26/15.
//  Copyright (c) 2015 Kavya V. Hegde. All rights reserved.
//

import Foundation

class Event {
    
    var eventTitle:String
    var eventPrice:String
    var eventImageName:String?
    
    init(dataDictionary:Dictionary<String,String>) {
        eventPrice = dataDictionary["eventPrice"]!
        eventTitle = dataDictionary["eventTitle"]!
        eventImageName = dataDictionary["eventImageName"]
    }
    
    class func newEvent(dataDictionary:Dictionary<String,String>) -> Event {
        return Event(dataDictionary: dataDictionary)
    }
    
    class func eventsList() -> [Event] {
        
        var array = [Event]()
        let dataPath = NSBundle.mainBundle().pathForResource("events", ofType: "plist")
        
        let data = NSArray(contentsOfFile: dataPath!)
        
        for e in data as [Dictionary<String, String>] {
            let event = Event(dataDictionary: e)
            array.append(event)
        }
        
        return array
    }
    
}