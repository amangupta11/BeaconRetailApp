//
//  tableInterfaceController.swift
//  POC
//
//  Created by Maithri VM on 02/06/15.
//  Copyright (c) 2015 Kavya V. Hegde. All rights reserved.
//

import WatchKit
import Foundation


class tableInterfaceController: WKInterfaceController {
    @IBOutlet weak var interfaceTable: WKInterfaceTable!
    var _eventsData:[Event] = [Event]()
    
    
    override func awakeWithContext(context: AnyObject?) {
        super.awakeWithContext(context)
        
        // Configure interface objects here.
        if let Events = context as? NSArray{
            _eventsData = Events as! [Event];
            
            self.loadTableData()
        }
    }
    
    
    func loadTableData() {
        interfaceTable.setNumberOfRows(_eventsData.count, withRowType: "default")
        
        for (index, event) in _eventsData.enumerate() {
            if let row = interfaceTable.rowControllerAtIndex(index) as? tableRowController {
                row.rowLabel.setText(event.eventTitle)
                row.rowImage.setImageNamed(event.eventImageName)
            }
        }
        
    }
    
    
    override func table(table: WKInterfaceTable,
        didSelectRowAtIndex rowIndex: Int)
    {
        presentControllerWithName("SecondController", context:_eventsData[rowIndex])
        //pushControllerWithName("SecondController", context:_eventsData[rowIndex])
        
    }
    
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }
    
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }
    
}
