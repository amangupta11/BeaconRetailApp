//
//  SecondController.swift
//  POC
//
//  Created by Kavya V. Hegde on 4/22/15.
//  Copyright (c) 2015 Kavya V. Hegde. All rights reserved.
//

import WatchKit
import Foundation


class SecondController: WKInterfaceController {

       //var offerItem: Event!
    
    @IBOutlet weak var Label: WKInterfaceLabel!
    //var dataPassed:String!
    @IBOutlet weak var image: WKInterfaceImage!
    //var seconddata:String!
    @IBOutlet weak var Price: WKInterfaceLabel!
    
    
    @IBOutlet weak var Weight: WKInterfaceLabel!
    @IBOutlet weak var eDetail: WKInterfaceLabel!
    
    @IBAction func Close() {
        dismissController()
    }
    
  //  @IBOutlet weak var Description: WKInterfaceLabel!
    override func awakeWithContext(context: AnyObject?) {
     //   super.awakeWithContext(context)
            if let Event = context as? Event
            {
                Label.setText(Event.eventTitle)
                Price.setText(Event.eventPrice)
                image.setImageNamed(Event.eventImageName)
                eDetail.setText(Event.eventdetail)
                Weight.setText(Event.eventWeight)
        // var offerItems = context as
    // Title
    //    Title.setText()
        }
        
    }
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

}
