//
//  InterfaceController.swift
//  POC WatchKit Extension
//
//  Created by Kavya V. Hegde on 4/22/15.
//  Copyright (c) 2015 Kavya V. Hegde. All rights reserved.
//

import WatchKit
import Foundation


class InterfaceController: WKInterfaceController {
    
    
    @IBOutlet weak var items: WKInterfaceLabel!
    @IBOutlet weak var List: WKInterfaceButton!
   
    @IBOutlet weak var cart: WKInterfaceButton!
    @IBOutlet weak var offers: WKInterfaceButton!
        @IBOutlet weak var Wallet: WKInterfaceButton!
    
//et features=["","]
   // let features = ["Apps","Image"]
      var _eventsData:[Event] = [Event]()
    
      //  var img:UIImage(named:"cart.png")!
    @IBAction func BrowsebuttonTapped()
    {
        
        let controllers = [String](count: _eventsData.count, repeatedValue: "ListController")
        presentControllerWithNames(controllers, contexts: _eventsData)
        
        
    }
    override func awakeWithContext(context: AnyObject?) {
        
               super.awakeWithContext(context)
        
        let img:UIImage = UIImage(named: "my_offers.png")!
        WKInterfaceDevice().addCachedImage(img, name: "my_offers.png")
        
        self.List.setBackgroundImageNamed("my_offers.png")
        
        
        let img1:UIImage = UIImage(named: "wallet.png")!
        WKInterfaceDevice().addCachedImage(img1, name: "wallet.png")
        
        self.Wallet.setBackgroundImageNamed("wallet.png")
        
        let img2:UIImage = UIImage(named: "Shopping_List.png")!
        WKInterfaceDevice().addCachedImage(img2, name: "Shopping_List.png")
        self.offers.setBackgroundImageNamed("Shopping_List.png")        //self.offers.setBackgroundImageNamed("my_offers.png")
        
        let img3:UIImage = UIImage(named: "cart.png")!
        WKInterfaceDevice().addCachedImage(img3, name: "cart.png")
        
        self.cart.setBackgroundImageNamed("cart.png")
        
        _eventsData = Event.eventsList()
        
    }
    
    override func willActivate() {
        super.willActivate()
        
    }
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }
    
    override func handleActionWithIdentifier(identifier: String?, forLocalNotification localNotification: UILocalNotification) {
        
        if let notificationIdentifier = identifier{
            if notificationIdentifier == "ViewAction"{
               
        let Offers:NSDictionary = localNotification.userInfo!
        
        let itemName = Offers["itemName"]as! String
        
        let itemPrice = Offers["itemPrice"]as! String
        
        let itemWeight = Offers["itemWeight"] as! String
        
        let itemImage = Offers["itemImage"]as! String
        
        let itemDetail = Offers["itemDetail"]as! String
        
        
       
        
        let newItem = NSMutableDictionary ()
        newItem.setValue(itemName , forKey:"eventTitle")
        newItem.setValue(itemPrice, forKey: "eventPrice")
        newItem.setValue(itemImage, forKey: "eventImageName" )
        newItem.setValue(itemDetail, forKey: "eventDetail" )
        newItem.setValue(itemWeight , forKey:"eventWeight")
                
        self.addNewOffer(newItem)
        _eventsData = Event.eventsList()
        let controllers = [String](count: _eventsData.count, repeatedValue: "ListController")
        presentControllerWithNames(controllers, contexts: _eventsData)
              
            }
        }

        

    }
    
    override func handleActionWithIdentifier(identifier: String?, forRemoteNotification remoteNotification: [NSObject : AnyObject]) {
        if let notificationIdentifier = identifier{
            if notificationIdentifier == "ViewAction"{
                
                
                let newItem = NSMutableDictionary ()
                newItem.setValue("Apples", forKey:"eventTitle")
                newItem.setValue("$14:20", forKey: "eventPrice")
                newItem.setValue("11.04 o.z", forKey:"eventWeight")

                newItem.setValue("red_apples.png", forKey: "eventImageName" )
                newItem.setValue("Product details Lorem ipsum dolor sit amet", forKey: "eventDetail" )
                self.addNewOffer(newItem)
                
                _eventsData = Event.eventsList()
                let controllers = [String](count: _eventsData.count, repeatedValue: "ListController")
                presentControllerWithNames(controllers, contexts: _eventsData)
            }
        }
    }
   
    override func contextForSegueWithIdentifier(segueIdentifier: String) -> AnyObject? {
            if (segueIdentifier == "product")
            {
                return _eventsData
            }
            else
            {
                return nil;
                
            }
    }
    
    func addNewOffer(newOffer:NSDictionary)
    {
        Event.update(newOffer)

    }
}

