//
//  NotificationController.swift
//  POC
//
//  Created by Aman Gupta on 02/06/15.
//  Copyright (c) 2015 Kavya V. Hegde. All rights reserved.
//

import WatchKit
import Foundation


class NotificationController: WKUserNotificationInterfaceController {

    
    
    @IBOutlet weak var alertTitle: WKInterfaceLabel!
    
    
    @IBOutlet weak var alertmsg: WKInterfaceLabel!
    
    @IBOutlet weak var fruitImage: WKInterfaceImage!
    
    
    @IBOutlet weak var itemWeight: WKInterfaceLabel!
    
   
    
    @IBOutlet weak var itemPrice: WKInterfaceLabel!
    
   
    
    override init() {
        // Initialize variables here.
        super.init()
        
        // Configure interface objects here.
    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        
       
        
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

    
    override func didReceiveLocalNotification(localNotification: UILocalNotification, withCompletion completionHandler: ((WKUserNotificationInterfaceType) -> Void)) {
        // This method is called when a local notification needs to be presented.
        // Implement it if you use a dynamic notification interface.
        // Populate your dynamic notification interface as quickly as possible.
        //
        // After populating your dynamic notification interface call the completion block.
        
        
        let Offers:NSDictionary = localNotification.userInfo!
        
        
        
            let itemPrice = Offers["itemPrice"]as! String
            
            let itemImage = Offers["itemImage"]as! String
            let itemWeight = Offers["itemWeight"]as! String
        
            self.alertTitle.setText(localNotification.alertTitle)
            self.alertmsg.setText(localNotification.alertBody)
            self.itemPrice.setText(itemPrice)
            self.fruitImage.setImageNamed(itemImage)
            self.itemWeight.setText(itemWeight)
        
       
           completionHandler(.Custom)
    }
    
    
    
    
    override func didReceiveRemoteNotification(remoteNotification: [NSObject : AnyObject], withCompletion completionHandler: ((WKUserNotificationInterfaceType) -> Void)) {

        if let aps = remoteNotification["aps"] as? NSDictionary {
            if let alert = aps["alert"] as? NSDictionary {
                if let title = alert["title"] as? String {
                    self.alertTitle.setText(title)
                    
                }
                if let body = alert["body"] as? String {
                    self.alertmsg.setText(body)
                }
            }
            
            
        }
        
        if let info = remoteNotification["info"] as? NSDictionary {
            
            if let itemPrice = info["itemPrice"]as? String{
                self.itemPrice.setText(itemPrice )
            }
            if let itemWeight = info["itemWeight"]as? String{
                self.itemWeight.setText(itemWeight)
            }
            if let itemImage = info["itemImage"]as? String{
                self.fruitImage.setImageNamed(itemImage)
            }
            
        }
//
//        self.alertTitle.setText("Hot offer!")
//        self.alertmsg.setText("20% off on bananas")
//        self.itemPrice.setText("$15/kg")
//        self.itemWeight.setText("11.04 o.z")
//        self.fruitImage.setImageNamed("bannanas")

        
        completionHandler(.Custom)
    }

    
   }
