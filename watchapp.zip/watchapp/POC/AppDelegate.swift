//
//  AppDelegate.swift
//  POC
//
//  Created by Kavya V. Hegde on 4/22/15.
//  Copyright (c) 2015 Kavya V. Hegde. All rights reserved.
//

import UIKit
import CoreLocation

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate,CLLocationManagerDelegate {
    
    var window: UIWindow?
    var locationManager1 , locationManager2 , locationManager3:CLLocationManager?
    var beaconUUId1 , beaconUUId2 , beaconUUId3:NSUUID?
    var lastProximity:CLProximity?
    var lastRangedBeaconId:NSString?
    
    var lastProxForB1:CLProximity?
    var lastProxForB2:CLProximity?
    
    func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {
        
        
        
        if(application.respondsToSelector("registerUserNotificationSettings:")) {
            application.registerUserNotificationSettings(
                UIUserNotificationSettings(
                    forTypes: [UIUserNotificationType.Alert, UIUserNotificationType.Sound, UIUserNotificationType.Badge],
                    categories: nil
                )
            )
        }
        
        configureBeacon1()
        configureBeacon2()
        configureBeacon3()
        
        
        DataAccessProxy.sharedInstance.copyDataSetToSharedGroup();
        
        
        return true
    }
    
    func  configureBeacon1(){
        
        let uuidString1 = "4506EFC7-0029-CD06-E32E-CCEFC70207CE"
        let beaconIdentifier1 = "Identifier1"
        beaconUUId1 = NSUUID(UUIDString: uuidString1)
        let beaconRegion1:CLBeaconRegion = CLBeaconRegion(proximityUUID: beaconUUId1!, major: 0003, minor: 0002, identifier: beaconIdentifier1)
        
        locationManager1 = CLLocationManager()
        
        
        if (CLLocationManager.authorizationStatus() != CLAuthorizationStatus.AuthorizedWhenInUse) {
            
            locationManager1!.requestAlwaysAuthorization()
        }
        
        locationManager1!.delegate = self
        locationManager1!.pausesLocationUpdatesAutomatically = false
        locationManager1!.startMonitoringForRegion(beaconRegion1)
        locationManager1!.startRangingBeaconsInRegion(beaconRegion1)
        locationManager1?.requestStateForRegion(beaconRegion1)
        
        locationManager1!.startUpdatingLocation()
        
        
        
        
        
        
    }
    
    func configureBeacon2(){
        
        
        let uuidString2 = "4506EFC7-0029-CD06-E32E-CCEFC70207CE"
        let beaconIdentifier2 = "Identifier2"
        beaconUUId2 = NSUUID(UUIDString: uuidString2)
        let beaconRegion2:CLBeaconRegion = CLBeaconRegion(proximityUUID: beaconUUId2! , major: 0003, minor: 0003, identifier: beaconIdentifier2)
        
        locationManager2 = CLLocationManager()
        
        
        if (CLLocationManager.authorizationStatus() != CLAuthorizationStatus.AuthorizedWhenInUse) {
            
            locationManager2!.requestAlwaysAuthorization()
        }
        locationManager2!.delegate = self
        locationManager2!.pausesLocationUpdatesAutomatically = false
        locationManager2!.startMonitoringForRegion(beaconRegion2)
        locationManager2!.startRangingBeaconsInRegion(beaconRegion2)
        locationManager2?.requestStateForRegion(beaconRegion2)
        
        locationManager2!.startUpdatingLocation()
        
        
        
        
        
    }
    
    
    func configureBeacon3(){
        
        let uuidString3 = "69C5FD60-C317-4C16-8616-ADD8A6979B29"
        let beaconIdentifier3 = "Identifier3"
        beaconUUId3 = NSUUID(UUIDString: uuidString3)
        let beaconRegion3:CLBeaconRegion = CLBeaconRegion(proximityUUID: beaconUUId3!, identifier: beaconIdentifier3)
        
        locationManager3 = CLLocationManager()
        
        
        if (CLLocationManager.authorizationStatus() != CLAuthorizationStatus.AuthorizedWhenInUse) {
            
            locationManager3!.requestAlwaysAuthorization()
        }
        locationManager3!.delegate = self
        locationManager3!.pausesLocationUpdatesAutomatically = false
        locationManager3!.startMonitoringForRegion(beaconRegion3)
        locationManager3!.startRangingBeaconsInRegion(beaconRegion3)
        locationManager3?.requestStateForRegion(beaconRegion3)
        
        locationManager3!.startUpdatingLocation()
        
        
    }
    
    func applicationWillResignActive(application: UIApplication) {
    }
    
    func applicationDidEnterBackground(application: UIApplication) {
        
    }
    
    func applicationWillEnterForeground(application: UIApplication) {
        
    }
    
    func applicationDidBecomeActive(application: UIApplication) {
    }
    
    func applicationWillTerminate(application: UIApplication) {
    }
    
    
    
    func beaconNotificationMessage(message: String!,title: String!,itemInfo: Dictionary<String , String>, playSound: Bool) {
        
        let notification:UILocalNotification = UILocalNotification()
        
        notification.fireDate = NSDate(timeIntervalSinceNow: 5)
        notification.timeZone = NSTimeZone.defaultTimeZone()
        notification.alertTitle = title
        notification.alertBody = message
        
        notification.userInfo = itemInfo
        
        notification.applicationIconBadgeNumber = UIApplication.sharedApplication().applicationIconBadgeNumber+1
        if(playSound) {
            
            notification.soundName = "tos_beep.caf";
        }
        UIApplication.sharedApplication().scheduleLocalNotification(notification)
    }
    
    func locationManager(manager: CLLocationManager, didRangeBeacons beacons: [CLBeacon], inRegion region: CLBeaconRegion) {
        
        
        let viewController:ViewController = window!.rootViewController as! ViewController
        viewController.beacons = (beacons as [CLBeacon]?)!
        
        var itemInfo = Dictionary<String,String>()
        
        var message:String = ""
        var title:String = ""
        
        var playSound = false
        
        if(beacons.count > 0) {
            
            let nearestBeacon:CLBeacon = beacons[0] as CLBeacon
            
            
            
            lastProximity = nearestBeacon.proximity;
            
            
            
            if region.isKindOfClass(CLBeaconRegion.self){
                
                let beaconRegion:CLBeaconRegion = region as CLBeaconRegion
                if beaconRegion.proximityUUID.isEqual(beaconUUId1){
                    lastRangedBeaconId = beaconUUId1?.UUIDString
                    if lastProxForB1==nearestBeacon.proximity
                    {
                        return
                    }
                    lastProxForB1 = nearestBeacon.proximity
                    switch nearestBeacon.proximity {
                        
                    case CLProximity.Near:
                        playSound = true
                        title = "Hot Offer!"
                        message = "20%% off on Bananas"
                        itemInfo["itemName"] = "Banana"
                        itemInfo["itemPrice"] = "$8"
                        itemInfo["itemWeight"] = "11.04 o.z"
                        itemInfo["itemImage"] = "bannanas"
                        itemInfo["itemDetail"] = "Nendran bananas are a variety of banana."
                        beaconNotificationMessage(message,title: title,itemInfo:itemInfo, playSound: playSound)
                        
                    default:
                        return
                    }
                    
                }
                    /*else if beaconRegion.proximityUUID.isEqual(beaconUUId2){
                    switch nearestBeacon.proximity {
                    
                    case CLProximity.Far:
                    playSound = false
                    
                    case CLProximity.Near,CLProximity.Immediate:
                    playSound = true
                    title = "Hot Offer!"
                    message = "10%% off on Red Apples"
                    itemInfo["itemName"] = "Red Apples"
                    itemInfo["itemPrice"] = "$10"
                    itemInfo["itemWeight"] = "7.33 o.z"
                    itemInfo["itemImage"] = "red_apples"
                    itemInfo["itemDetail"] = "Apples are a natural supply of fibre and are fat free."
                    beaconNotificationMessage(message,title: title,itemInfo:itemInfo, playSound: playSound)
                    
                    
                    case CLProximity.Unknown:
                    return
                    }
                    
                    
                    
                    }*/
                else if beaconRegion.proximityUUID.isEqual(beaconUUId3){
                    lastRangedBeaconId = beaconUUId3?.UUIDString
                    if lastProxForB2==nearestBeacon.proximity
                    {
                        return
                    }
                    lastProxForB2 = nearestBeacon.proximity
                    
                    switch nearestBeacon.proximity {
                        
                        
                    case CLProximity.Near:
                        playSound = true
                        title = "Hot Offer!"
                        message = "5%% off on Fairlife milk "
                        itemInfo["itemName"] = "Fairlife milk"
                        itemInfo["itemPrice"] = "$11"
                        itemInfo["itemWeight"] = "5.06 o.z"
                        itemInfo["itemImage"] = "fairlife_milk"
                        itemInfo["itemDetail"] = "Skimmed milk produced by farmers."
                        beaconNotificationMessage(message,title: title,itemInfo:itemInfo, playSound: playSound)
                        
                    default:
                        return
                    }
                    
                }
            }
            
            
        }
        
        
        
        
        
    }
    
    func application(application: UIApplication, didReceiveLocalNotification notification: UILocalNotification) {
        application.applicationIconBadgeNumber = 0
        
        
        let state:UIApplicationState = application.applicationState
        if state == UIApplicationState.Active{
            let  alert:UIAlertView = UIAlertView(title:notification.alertTitle, message:notification.alertBody, delegate: self, cancelButtonTitle: "Ok")
            alert.show()
        }
        
        
        
    }
    
    
    func locationManager(manager: CLLocationManager, didDetermineState state: CLRegionState, forRegion region: CLRegion) {
        
    }
    
    func locationManager(manager: CLLocationManager, didEnterRegion region: CLRegion) {
        
        manager.startRangingBeaconsInRegion(region as! CLBeaconRegion)
        manager.startUpdatingLocation()
        
        
        NSLog("You entered the region")
        
        
        
        //beaconNotificationMessage("Get 20%% off on bananas", playSound: false)
        
        
        
    }
    
    
    func locationManager(manager: CLLocationManager, didExitRegion region: CLRegion) {
        
        manager.stopRangingBeaconsInRegion(region as! CLBeaconRegion)
        manager.stopUpdatingLocation()
        
        NSLog("You exited the region")
        
        
        // beaconNotificationMessage("Please Revisit our shop and get updates for new offers", playSound: true)
        
        
    }
    
    
}

