//
//  DataAccessProxy.swift
//  POC
//
//  Created by Maithri VM on 02/06/15.
//  Copyright (c) 2015 Kavya V. Hegde. All rights reserved.
//

import UIKit
let sharedAppGroup:String = "group.com.techendeavour.retail"

public class DataAccessProxy: NSObject {
    
    private let listUtilitiesQueue = NSOperationQueue()
    private let offersPlistFilePath = "offers.plist"
    public class var sharedInstance : DataAccessProxy {
        struct Static {
            static let instance : DataAccessProxy = DataAccessProxy()
        }
        return Static.instance
    }
    
    public class var localDocumentsDirectory: NSURL  {
        let documentsURL = sharedApplicationGroupContainer.URLByAppendingPathComponent("Documents", isDirectory: true)
        
        var error: NSError?
        // This will return `true` for success if the directory is successfully created, or already exists.
        let success: Bool
        do {
            try NSFileManager.defaultManager().createDirectoryAtURL(documentsURL, withIntermediateDirectories: true, attributes: nil)
            success = true
        } catch let error1 as NSError {
            error = error1
            success = false
        }
        
        if success {
            return documentsURL
        }
        else {
            fatalError("The shared application group documents directory doesn't exist and could not be created. Error: \(error!.localizedDescription)")
        }
    }
    
    private class var sharedApplicationGroupContainer: NSURL {
        let containerURL = NSFileManager.defaultManager().containerURLForSecurityApplicationGroupIdentifier(sharedAppGroup)
        
        if containerURL == nil {
            fatalError("The shared application group container is unavailable. Check your entitlements and provisioning profiles for this target. Details on proper setup can be found in the PDFs referenced from the README.")
        }
        
        return containerURL!
    }
    
    public func copyDataSetToSharedGroup(){
        
        //var error: NSError? = nil
        
        let sharedContainerURL: NSURL? = DataAccessProxy.localDocumentsDirectory
        if let _ = sharedContainerURL {
            //let storeURL = sharedContainerURL.URLByAppendingPathComponent("events.plist")
            
            if let url = NSBundle.mainBundle().URLForResource("offers", withExtension: "plist") {
                if NSFileManager.defaultManager().fileExistsAtPath(url.path!) {
                    print("file found", terminator: "")
                    copyURLToDocumentsDirectory(url)
                }
            }
            
            //let url = NSBundle.mainBundle().URLForResource("events", withExtension:"plist")
            //var coordinator: NSPersistentStoreCoordinator? = NSPersistentStoreCoordinator(managedObjectModel: self.managedObjectModel)
            //if coordinator!.addPersistentStoreWithType(NSSQLiteStoreType, configuration: nil, URL: storeURL, options: nil, error: &error) == nil {
            // error handling goes here
            //abort()
        }
        //return coordinator
        
    }
    
    func copyURLToDocumentsDirectory(url: NSURL) {
        let toURL: NSURL? = DataAccessProxy.localDocumentsDirectory.URLByAppendingPathComponent(offersPlistFilePath, isDirectory: false)
        
        let fileCoordinator = NSFileCoordinator()
        var error: NSError?
        
        if NSFileManager().fileExistsAtPath(toURL!.path!) {
            // If the file already exists, don't attempt to copy the version from the bundle.
            return
        }
        
        // `url` may be a security scoped resource.
        let successfulSecurityScopedResourceAccess = url.startAccessingSecurityScopedResource()
        
        let movingIntent = NSFileAccessIntent.writingIntentWithURL(url, options: .ForMoving)
        let replacingIntent = NSFileAccessIntent.writingIntentWithURL(toURL!, options: .ForReplacing)
        fileCoordinator.coordinateAccessWithIntents([movingIntent, replacingIntent], queue: self.listUtilitiesQueue) { accessError in
            if accessError != nil {
                print("Couldn't move file: \(movingIntent.URL) to: \(replacingIntent.URL) error: \(accessError!.localizedDescription).")
                return
            }
            
            var success = false
            
            let fileManager = NSFileManager()
            
            do {
                try fileManager.copyItemAtURL(movingIntent.URL, toURL: replacingIntent.URL)
                success = true
            }
            catch let error1 as NSError {
                error = error1
                success = false
            }
            catch {
                fatalError()
            }
            
            if success {
                let fileAttributes = [NSFileExtensionHidden: true]
                
                do {
                    try fileManager.setAttributes(fileAttributes, ofItemAtPath: replacingIntent.URL.path!)
                }
                catch _ {
                }
            }
            
            if successfulSecurityScopedResourceAccess {
                url.stopAccessingSecurityScopedResource()
            }
            
            if !success {
                // An error occured when moving `url` to `toURL`. In your app, handle this gracefully.
                print("Couldn't move file: \(url) to: \(toURL).", terminator: "")
            }
        }
    }
    
    func getOffersPlistData()->NSArray
    {
        let array = []
        let toURL: NSURL? = DataAccessProxy.localDocumentsDirectory.URLByAppendingPathComponent(offersPlistFilePath, isDirectory: false)
        let dataPath = toURL?.path
        
        if NSFileManager.defaultManager().fileExistsAtPath(dataPath!)
        {
            if let contents = NSArray(contentsOfFile: dataPath!)
            {
                return contents
                
            }
        }
        return array
    }
    func update(data:NSDictionary) {
        
        let toURL: NSURL? = DataAccessProxy.localDocumentsDirectory.URLByAppendingPathComponent(offersPlistFilePath, isDirectory: false)
        let dataPath = toURL?.path
        
        
        if NSFileManager.defaultManager().fileExistsAtPath(dataPath!)
        {
            var arr = NSMutableArray()
            if let oldData = self.getOffersPlistData() as? NSArray{
                arr = NSMutableArray(array:oldData)
            }
            
            //arr.addObject(data)
            arr.insertObject(data, atIndex: 0)
            arr.writeToFile(dataPath!, atomically: true)
            
        }
    }
}


